package io.github.goodsaem.freemarker.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class City {
    private String lcode;
    private String lname;
    private String mcode;
    private String mname;
    private String scode;
    private String sname;
}