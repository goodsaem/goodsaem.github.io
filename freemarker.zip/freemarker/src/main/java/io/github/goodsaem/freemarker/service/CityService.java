package io.github.goodsaem.freemarker.service;

import io.github.goodsaem.freemarker.model.City;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.stereotype.Service;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Service
public class CityService implements ICityService {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<City> findAll() {
        var sql = "SELECT * FROM hcode";
        return jdbcTemplate.query(sql,new BeanPropertyRowMapper<>(City.class));
    }

    @Override
    public Boolean createCode(String lcode, String lname, String mcode, String mname, String scode, String sname) {
        var sql = "insert into hcode(lcode,lname,mcode,mname,scode,sname) values (?,?,?,?,?,?)";
        return jdbcTemplate.execute(sql, new PreparedStatementCallback<Boolean>() {
            @Override
            public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
                ps.setString(1,lcode);
                ps.setString(2,lname);
                ps.setString(3,mcode);
                ps.setString(4,mname);
                ps.setString(5,scode);
                ps.setString(6,sname);
                return ps.execute();
            }
        });
    }

    @Override
    public void createTable() {
        var sql = "DROP TABLE IF EXISTS HCODE";
        jdbcTemplate.execute(sql);

        sql =
        "CREATE TABLE IF NOT EXISTS HCODE ( "+
        "        LCODE VARCHAR(2), "+
        "        LNAME VARCHAR(255), "+
        "        MCODE VARCHAR(5), "+
        "        MNAME VARCHAR(255), "+
        "        SCODE VARCHAR(7) PRIMARY KEY, "+
        "       SNAME VARCHAR(255) "+
        ") ";
        jdbcTemplate.execute(sql);
    }
}