package io.github.goodsaem.freemarker.controller;

import io.github.goodsaem.freemarker.service.ICityService;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

@Controller
public class MyController {
    @Autowired
    private ICityService cityService;

    @GetMapping(value = "/")
    public String index(Model model){
        return "index";
    }

    @GetMapping(value="/cities")
    public ModelAndView showCities() {
        var cities = cityService.findAll();
        var params = new HashMap<String,Object>();

        params.put("cities",cities);

        return new ModelAndView("showCities",params);

    }
    @GetMapping(value = "/excel")
    public String excel(Model model){
        return "excel";
    }

    @PostMapping(value = "/uploadExcel")
    public ModelAndView uploadExcel(@RequestParam("file")MultipartFile file) throws IOException {
        cityService.createTable();

        var dataList = new ArrayList<>();
        String extension = FilenameUtils.getExtension(file.getOriginalFilename());
        if(!extension.equals("xlsx") && !extension.equals("xls")) {
            throw new IOException("only excel file!!");
        }

        Workbook workbook = null;
        if(extension.equals("xlsx")) {
            workbook = new XSSFWorkbook(file.getInputStream());
        } else if(extension.equals("xls")) {
            workbook = new HSSFWorkbook(file.getInputStream());
        }

        Sheet worksheet = workbook.getSheetAt(0);

        int k=0;
        for(int rowIndex=1; rowIndex<worksheet.getPhysicalNumberOfRows(); rowIndex++) {
            Row row = worksheet.getRow(rowIndex);
            if(row != null) {
                int cells = row.getPhysicalNumberOfCells();
                var hashMap = new HashMap();
                for(int columnIndex=0; columnIndex<= cells; columnIndex++) {
                    hashMap.put("col"+columnIndex,row.getCell(columnIndex) + "");
                }
                dataList.add(hashMap);
                cityService.createCode((String)hashMap.get("col0"),
                        (String)hashMap.get("col1"),
                        (String)hashMap.get("col2"),
                        (String)hashMap.get("col3"),
                        (String)hashMap.get("col4"),
                        (String)hashMap.get("col5"));
            }
        }

        var params = new HashMap<String,Object>();
        params.put("datas",dataList);
        return new ModelAndView("excelList",params);
    }
}