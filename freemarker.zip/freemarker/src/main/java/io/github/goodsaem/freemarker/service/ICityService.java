package io.github.goodsaem.freemarker.service;

import io.github.goodsaem.freemarker.model.City;
import java.util.List;

public interface ICityService {
    List<City> findAll();
    Boolean createCode(String lcode,String lname,String mcode,
                       String mname,String scode,String sname);
    void createTable();
}