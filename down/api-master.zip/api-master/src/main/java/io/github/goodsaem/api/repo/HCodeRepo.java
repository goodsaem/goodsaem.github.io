package io.github.goodsaem.api.repo;

import io.github.goodsaem.api.entity.HCode;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HCodeRepo extends CrudRepository<HCode,Long> {
}