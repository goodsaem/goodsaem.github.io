package io.github.goodsaem.api.service;

import io.github.goodsaem.api.entity.HCode;

import java.util.List;
import java.util.Map;

public interface IHCodeService {
    List<HCode> findAll();
    Map<String, List<HCode>> getHCodeMap();
}