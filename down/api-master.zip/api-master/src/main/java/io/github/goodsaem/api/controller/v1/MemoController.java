package io.github.goodsaem.api.controller.v1;

import io.github.goodsaem.api.entity.Memo;
import io.github.goodsaem.api.repo.MemoJpaRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping(value = "/v1")
public class MemoController {
    private final MemoJpaRepo memoJpaRepo;

    @GetMapping(value = "/memo")
    public List<Memo> findAllUser() {
        return memoJpaRepo.findAll();
    }

    @PostMapping(value = "/memo")
    public Memo save(@RequestBody Memo memo) {
        return memoJpaRepo.save(memo);
    }
}