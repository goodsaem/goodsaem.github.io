package io.github.goodsaem.api.service;

import io.github.goodsaem.api.entity.HCode;
import io.github.goodsaem.api.repo.HCodeRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class HCodeService implements  IHCodeService{
    @Autowired
    private HCodeRepo hCodeRepo;

    @Override
    public List<HCode> findAll() {
        return (List<HCode>) hCodeRepo.findAll();
    }

    @Override
    public Map<String, List<HCode>> getHCodeMap() {
        Map hash = new HashMap();
        hash.put("hCodeCache",hCodeRepo.findAll());
        Map<String, List<HCode>>  hCodeMap =hash;
        return hCodeMap;
    }
}