package io.github.goodsaem.api.controller;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {

    private final String MSG="안녕하세요 좋은 선생님 goodsaem! 입니다.";

    @Setter
    @Getter
    public static class JsonObj {
        private String msg;
    }

    @GetMapping(value = "/goodsaem/string")
    @ResponseBody
    public String getString() {
        return MSG;
    }

    @GetMapping(value = "/goodsaem/json")
    @ResponseBody
    public JsonObj getJson() {
        JsonObj obj = new JsonObj();
        obj.msg  = MSG;
        return obj;
    }

    @GetMapping(value = "/goodsaem/page")
    public String helloworld() {
        return "goodsaem";
    }
}
